
------------------------
EdgeSweep v 1.0

by    DNS-Plugins
web:  www.dns-plugins.de
mail: support@dns-plugins.de
------------------------




Introduction
------------------
This Generator plugin generates sweep Objects out of EdgeSelections.
Deformations of the source Object are considered and matched.


Installation
------------------
Extract the Plugin-files into your cinema4d plugins folder.
After restarting cinema, the plugin is available from the plugins menu.


License
------------------
The Plugin can be used free of charge for private or commercial work.


How to use
------------------
Start the plugin by selecting it from the plugin menu.
This will insert a EdgeSweep Generator into your scene.
Drag the edge selection that xyou want to sweep into the corresponding link-field of the EdgeSweep 
generator.Also drag the profile spline that you want to sweep along the edge-path into its link field.
Now you can adjust some settins in the generator, like offset from the surface and interpolation modes for the sweep splines.




Disclaimer
------------------

The creator of the Software cannot be held responsible for any
damages or loss of data that may occur during the use of this plugin. 
The software is provided AS IS with no warranties. 
Use at your own risk!